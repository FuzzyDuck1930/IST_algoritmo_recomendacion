export interface typeNeko {
    anime_name: string;
    url: string;
    name: string;
    image: string;
    species: string;
    status: string;
}